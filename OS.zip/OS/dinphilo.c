#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>

#define N 5
#define THINKING 2
#define HUNGRY 1
#define EATING 0
#define LEFT (phnum + 4) % N
#define RIGHT (phnum + 1) % N

int state[N];
int phil[N] = { 0, 1, 2, 3, 4 };

sem_t mutex;
sem_t S[N];

void* philosopher(void* num)
{
    int* i = num;
    int phnum = *i;

    while (1) {
        // No automatic transitioning between states here
        sleep(1);
    }
}

int main()
{
    int i;
    pthread_t thread_id[N];

    // initialize the semaphores
    sem_init(&mutex, 0, 1);

    for (i = 0; i < N; i++)
        sem_init(&S[i], 0, 0);

    for (i = 0; i < N; i++) {
        // create philosopher processes
        pthread_create(&thread_id[i], NULL, philosopher, &phil[i]);
        printf("Philosopher %d is thinking\n", i + 1);
    }

    char choice;
    int phnum;

    while (1) {
        printf("Select an action:\n");
        printf("1. Make a philosopher hungry\n");
        printf("2. Make a philosopher think\n");
        printf("3. Make a philosopher eat\n");
        printf("4. Exit\n");
        printf("Choice: ");
        scanf(" %c", &choice);

        switch (choice) {
            case '1':
                printf("Enter the philosopher number to make hungry: ");
                scanf("%d", &phnum);
                state[phnum-1] = HUNGRY;
                printf("Philosopher %d is now hungry\n", phnum);
                break;
            case '2':
                printf("Enter the philosopher number to make think: ");
                scanf("%d", &phnum);
                state[phnum-1] = THINKING;
                printf("Philosopher %d is now thinking\n", phnum);
                break;
            case '3':
                printf("Enter the philosopher number to make eat: ");
                scanf("%d", &phnum);
                state[phnum-1] = EATING;
                printf("Philosopher %d is now eating\n", phnum);
                break;
            case '4':
                printf("Exiting...\n");
                sem_destroy(&mutex);
                for (i = 0; i < N; i++)
                    sem_destroy(&S[i]);
                for (i = 0; i < N; i++)
                    pthread_join(thread_id[i], NULL);
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
}
