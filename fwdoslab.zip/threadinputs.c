#include <stdio.h>
#include <pthread.h>
#include <stdlib.h> // Include the standard library for memory allocation

// Struct to hold the details
struct ThreadDetails {
    char name[50];
    char registerNumber[20];
};

// Function to be executed by the thread
void* pass_details(void* details) {
    struct ThreadDetails* threadDetails = (struct ThreadDetails*)details;
    printf("Thread ID - %d\n", (int)pthread_self());
    printf("Name: %s\nRegister Number: %s\n", threadDetails->name, threadDetails->registerNumber);
    return NULL;
}

int main() {
    pthread_t tid;
    struct ThreadDetails *details = (struct ThreadDetails*)malloc(sizeof(struct ThreadDetails)); // Allocate memory for details

    // Get input from the user
    printf("Enter your name: ");
    scanf("%s", details->name);
    printf("Enter your register number: ");
    scanf("%s", details->registerNumber);

    // Create and start the thread
    pthread_create(&tid, NULL, pass_details, (void*)details);

    // Wait for the thread to finish
    pthread_join(tid, NULL);

    free(details); // Free the allocated memory

    return 0;
}

