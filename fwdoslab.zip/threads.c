#include <stdio.h>
#include <pthread.h>

// Function to be executed by the threads
void* print_id(void* message) {
    printf("%s: Thread ID - %d\n", (char*)message, (int)pthread_self());
    return NULL;
}

// Function to create and start threads
void create_threads() {
    pthread_t t1, t2;
    char* message1 = "First Thread";
    char* message2 = "Second Thread";

    // Create and start the first thread
    pthread_create(&t1, NULL, print_id, (void*)message1);

    // Create and start the second thread
    pthread_create(&t2, NULL, print_id, (void*)message2);

    // Wait for the threads to finish
    pthread_join(t1, NULL);
    pthread_join(t2, NULL);
}

int main() {
    // Call the function to create and start the threads
    create_threads();

    return 0;
}

