#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>

#define NUM_MEMBERS 2

sem_t mutex, writeMutex;
int readers = 0;

void* reader(void* arg) {
    int member_id = *(int*)arg;
    printf("Team member %d is reading the file.\n", member_id);
    sem_wait(&mutex);
    readers++;
    if (readers == 1) {
        sem_wait(&writeMutex);
    }
    sem_post(&mutex);

    // Read file contents
    printf("Team member %d is reading the current status of the project from the file.\n", member_id);

    sem_wait(&mutex);
    readers--;
    if (readers == 0) {
        sem_post(&writeMutex);
    }
    sem_post(&mutex);
    return NULL;
}

void* writer(void* arg) {
    int member_id = *(int*)arg;
    printf("Team member %d is updating the file.\n", member_id);
    sem_wait(&writeMutex);
    // Update file contents
    printf("Team member %d is updating the current status of the project in the file.\n", member_id);
    sem_post(&writeMutex);
    return NULL;
}

int main() {
    pthread_t readers_threads[NUM_MEMBERS], writer_thread;
    int members_ids[NUM_MEMBERS];

    sem_init(&mutex, 0, 1);
    sem_init(&writeMutex, 0, 1);

    for (int i = 0; i < NUM_MEMBERS; i++) {
        members_ids[i] = i + 1;
        pthread_create(&readers_threads[i], NULL, reader, &members_ids[i]);
    }

    // Simulate multiple writes
    for (int i = 0; i < NUM_MEMBERS; i++) {
        pthread_create(&writer_thread, NULL, writer, &members_ids[i]);
        pthread_join(writer_thread, NULL);
    }

    for (int i = 0; i < NUM_MEMBERS; i++) {
        pthread_join(readers_threads[i], NULL);
    }

    sem_destroy(&mutex);
    sem_destroy(&writeMutex);

    return 0;
}
