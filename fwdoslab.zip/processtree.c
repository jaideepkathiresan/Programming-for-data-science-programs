#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

void generateProcessTree() {
    pid_t pid_P2, pid_P3, pid_P5, pid_P6, pid_P7, pid_P4, pid_P8, pid_P10, pid_P11;

    // Creating process P2
    pid_P2 = fork();
    if (pid_P2 < 0) {
        fprintf(stderr, "Fork failed\n");
        exit(1);
    } else if (pid_P2 == 0) {
        // Child process P2
        printf("P2 (PID: %d, Parent PID: %d)\n", getpid(), getppid());
        
        // Creating process P5
        pid_P5 = fork();
	if (pid_P5 < 0) {
	    fprintf(stderr, "Fork failed\n");
	    exit(1);
	} else if (pid_P5 == 0) {
	    // Child process P5
	    printf("P5 (PID: %d, Parent PID: %d)\n", getpid(), getppid());  // Print P5's parent PID (P2)

	    // Creating process P10
	    pid_t pid_P10;
	    pid_P10 = fork();
	    if (pid_P10 < 0) {
		fprintf(stderr, "Fork failed\n");
		exit(1);
	    } else if (pid_P10 == 0) {
		// Child process P10
		printf("P10 (PID: %d, Parent PID: %d)\n", getpid(), getppid());  // Print P10's parent PID (P5)
		exit(0);
	    }

	    exit(0);
}

        // Creating process P6
        pid_P6 = fork();
        if (pid_P6 < 0) {
            fprintf(stderr, "Fork failed\n");
            exit(1);
        } else if (pid_P6 == 0) {
            // Child process P6
            printf("P6 (PID: %d, Parent PID: %d)\n", getpid(), getppid());
            exit(0);
        }

        // Creating process P7
        pid_P7 = fork();
        if (pid_P7 < 0) {
            fprintf(stderr, "Fork failed\n");
            exit(1);
        } else if (pid_P7 == 0) {
            // Child process P7
            printf("P7 (PID: %d, Parent PID: %d)\n", getpid(), getppid());
            exit(0);
        }

        exit(0);
    }

    // Creating process P3
    pid_P3 = fork();
    if (pid_P3 < 0) {
        fprintf(stderr, "Fork failed\n");
        exit(1);
    } else if (pid_P3 == 0) {
        // Child process P3
        printf("P3 (PID: %d, Parent PID: %d)\n", getpid(), getppid());

        // Creating process P4
	pid_P4 = fork();
	if (pid_P4 < 0) {
	    fprintf(stderr, "Fork failed\n");
	    exit(1);
	} else if (pid_P4 == 0) {
	    // Child process P4
	    printf("P4 (PID: %d, Parent PID: %d)\n", getpid(), getppid());  // Print P4's parent PID (P3)

	    // Creating process P11
	    pid_t pid_P11;
	    pid_P11 = fork();
	    if (pid_P11 < 0) {
		fprintf(stderr, "Fork failed\n");
		exit(1);
	    } else if (pid_P11 == 0) {
		// Child process P11
		printf("P11 (PID: %d, Parent PID: %d)\n", getpid(), getppid());  // Print P11's parent PID (P4)
		exit(0);
	    }

	    // Rest of P4's code
	    exit(0);
	}

        // Creating process P8
        pid_P8 = fork();
        if (pid_P8 < 0) {
            fprintf(stderr, "Fork failed\n");5213
            exit(1);
        } else if (pid_P8 == 0) {
            // Child process P8
            printf("P8 (PID: %d, Parent PID: %d)\n", getpid(), getppid());
            exit(0);
        }

        exit(0);
    }

    // Parent process P1
    if (pid_P2 > 0 && pid_P3 > 0) {
        // Wait for all child processes to finish
        wait(NULL);
        wait(NULL);
    }
}

int main() {
    printf("P1 (PID: %d, Parent PID: %d)\n", getpid(), getppid());
    generateProcessTree();
    return 0;
}
