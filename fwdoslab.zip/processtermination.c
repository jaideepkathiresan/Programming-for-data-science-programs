#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {
    pid_t pid[5];
    int i;

    // Creating child processes
    for (i = 0; i < 5; i++) {
        pid[i] = fork();

        if (pid[i] < 0) {
            fprintf(stderr, "Fork failed\n");
            exit(1);
        } else if (pid[i] == 0) {
            // Child process
            printf("Child process %d (PID: %d) created.\n", i + 1, getpid());

            // Third child process should terminate first
            if (i == 2) {
                printf("Third child process %d (PID: %d) terminated.\n", i + 1, getpid());
                exit(0);
            }

            // First child process should terminate last but before the parent process
            if (i == 0) {
                sleep(2);
                printf("First child process %d (PID: %d) terminated.\n", i + 1, getpid());
                exit(0);
            }

            // Second child process should terminate before first child and after third child
            if (i == 1) {
                sleep(1);
                printf("Second child process %d (PID: %d) terminated.\n", i + 1, getpid());
                exit(0);
            }

            // Fourth child process should terminate last but before the parent process
            if (i == 3) {
                sleep(3);
                printf("Fourth child process %d (PID: %d) terminated.\n",i+1,getpid());
                exit(0);
            }

            // Other child processes
            exit(0);
        }
    }

    // Parent process
    for (i = 0; i < 5; i++) {
        wait(NULL);
    }

    printf("Parent process (PID: %d) terminated.\n", getpid());
    return 0;
}


