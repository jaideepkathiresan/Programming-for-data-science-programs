#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

void* thread_function(void* arg) {
    int thread_num = *((int*)arg);
    printf("Thread %d started\n", thread_num);
    sleep(3);  // Simulating some work
    printf("Thread %d finished\n", thread_num);
    pthread_exit(NULL);
}

int main() {
    pthread_t tid1, tid2;
    int thread1_num = 1, thread2_num = 2;

    // Create the threads
    pthread_create(&tid1, NULL, thread_function, &thread1_num);
    pthread_create(&tid2, NULL, thread_function, &thread2_num);

    // Simulate main thread doing some work
    sleep(1);

    // Terminate the second thread
    printf("Terminating thread 2\n");
    pthread_cancel(tid2);

    // Wait for the first thread to finish
    pthread_join(tid1, NULL);

    printf("Main thread finished\n");

    return 0;
}

