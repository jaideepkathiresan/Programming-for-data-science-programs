#include <stdio.h>

// Structure to represent a quiz team
struct Team {
    int id; // Team ID
    int arrival_time; // Arrival time for each round
    int burst_time; // Time given to answer the question
    int waiting_time; // Waiting time
    int turnaround_time; // Turnaround time
};

// Function to calculate average time and display Gantt chart
void findAverageTime(struct Team teams[], int n) {
    int total_waiting_time = 0, total_turnaround_time = 0;
    int current_time = 0;

    // Calculate waiting time and turnaround time for each team
    for (int i = 0; i < n; i++) {
        // Set waiting time for the first team to 0
        if (i == 0) {
            teams[i].waiting_time = 0;
        } else {
            teams[i].waiting_time = current_time - teams[i].arrival_time;
        }
        teams[i].turnaround_time = teams[i].waiting_time + teams[i].burst_time;

        // Update total waiting time and turnaround time
        total_waiting_time += teams[i].waiting_time;
        total_turnaround_time += teams[i].turnaround_time;

        // Update current time for the next team
        current_time += teams[i].burst_time;
    }

    // Display the table of details
    printf("Team  Arrival Time  Burst Time  Waiting Time  Turnaround Time\n");
    for (int i = 0; i < n; i++) {
        printf(" %d ", teams[i].id);
        printf("       %d ", teams[i].arrival_time);
        printf("           %d ", teams[i].burst_time);
        printf("         %d ", teams[i].waiting_time);
        printf("             %d\n", teams[i].turnaround_time);
    }

    // Calculate and display average waiting time and turnaround time
    printf("Average waiting time = %.2f minutes\n", (float)total_waiting_time / n);
    printf("Average turnaround time = %.2f minutes\n", (float)total_turnaround_time / n);
}

// Driver code
int main() {
    int num_teams;
    printf("Enter the number of teams participating in the quiz competition: ");
    scanf("%d", &num_teams);

    struct Team teams[num_teams];

    // Input details for each team
    for (int i = 0; i < num_teams; i++) {
        printf("Enter details for Team %d:\n", i + 1);
        teams[i].id = i + 1;
        printf("Arrival time for Team %d: ", i + 1);
        scanf("%d", &teams[i].arrival_time);
        printf("Burst time for Team %d: ", i + 1);
        scanf("%d", &teams[i].burst_time);
    }

    // Function call to calculate average time and display Gantt chart
    findAverageTime(teams, num_teams);

    return 0;
}

