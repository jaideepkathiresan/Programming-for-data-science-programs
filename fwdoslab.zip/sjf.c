#include <stdio.h>

// Structure to represent a customer
typedef struct {
    int customerNumber;
    int arrivalTime;
    int serviceTime;
    int waitingTime;
    int turnaroundTime;
    int numProducts;
} Customer;

int main() {
    int numCustomers;
    printf("Enter the number of customers: ");
    scanf("%d", &numCustomers);

    Customer customers[numCustomers];
    int i;

    // Input customer details
    for (i = 0; i < numCustomers; i++) {
        printf("Enter arrival time, service time, and number of products for customer %d: ", i + 1);
        scanf("%d %d %d", &customers[i].arrivalTime, &customers[i].serviceTime, &customers[i].numProducts);
        customers[i].customerNumber = i + 1;
    }

    // Sort customers based on the number of products in ascending order
    for (i = 0; i < numCustomers - 1; i++) {
        for (int j = 0; j < numCustomers - i - 1; j++) {
            if (customers[j].numProducts > customers[j + 1].numProducts) {
                Customer temp = customers[j];
                customers[j] = customers[j + 1];
                customers[j + 1] = temp;
            }
        }
    }

    // Calculate waiting time and turnaround time for each customer
    customers[0].waitingTime = 0;
    customers[0].turnaroundTime = customers[0].serviceTime;

    for (i = 1; i < numCustomers; i++) {
        customers[i].waitingTime = customers[i - 1].waitingTime + customers[i - 1].serviceTime - customers[i].arrivalTime;
        if (customers[i].waitingTime < 0) {
            customers[i].waitingTime = 0;
        }
        customers[i].turnaroundTime = customers[i].waitingTime + customers[i].serviceTime;
    }

    // Calculate average waiting time, average turnaround time, total waiting time, and total turnaround time
    float avgWaitingTime = 0;
    float avgTurnaroundTime = 0;
    int totalWaitingTime = 0;
    int totalTurnaroundTime = 0;

    for (i = 0; i < numCustomers; i++) {
        avgWaitingTime += customers[i].waitingTime;
        avgTurnaroundTime += customers[i].turnaroundTime;
        totalWaitingTime += customers[i].waitingTime;
        totalTurnaroundTime += customers[i].turnaroundTime;
    }

    avgWaitingTime /= numCustomers;
    avgTurnaroundTime /= numCustomers;

    // Display the Gantt chart order and customer ID
    printf("\nGantt Chart Order:\n");
    for (i = 0; i < numCustomers; i++) {
        printf("C%d ", customers[i].customerNumber);
    }
    printf("\n");

    // Display the waiting time and turnaround time of each customer
    printf("\nCustomer\tWaiting Time\tTurnaround Time\n");
    for (i = 0; i < numCustomers; i++) {
        printf("C%d\t\t%d\t\t%d\n", customers[i].customerNumber, customers[i].waitingTime, customers[i].turnaroundTime);
    }

    // Display the average waiting time, average turnaround time, total waiting time, and total turnaround time
    printf("\nAverage Waiting Time: %.2f\n", avgWaitingTime);
    printf("Average Turnaround Time: %.2f\n", avgTurnaroundTime);
    printf("Total Waiting Time: %d\n", totalWaitingTime);
    printf("Total Turnaround Time: %d\n", totalTurnaroundTime);

    return 0;
}

