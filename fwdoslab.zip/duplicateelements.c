#include <stdio.h>
int main(){
    int n,arr[100],i,j,count=0;
    printf("Enter the length of array :");
    scanf("%d",&n);
    printf("Enter array elements\n");
    for (i=0;i<n;i++){
        scanf("%d",&arr[i]);
    }
    printf("Duplicate elements in the given array : ");
    for (i=0;i<n;i++){
        for (j=i+1;j<n;j++){
            if (arr[i]==arr[j]){
                count++;
                printf("%d (position %d and %d)\n",arr[i],i+1,j+1);
            }
        }
    }
    if (count==0){
        printf("No duplicates found\n");
    }
    return 0;
}
